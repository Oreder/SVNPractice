// hash.c

#include "list.h"
#include "hash.h"

// ...