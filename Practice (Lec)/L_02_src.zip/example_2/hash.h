// hash.h

#include "list.h"

// ...