// list.h

typedef int int_t;


struct list_node
{
    void *data;
    struct list_node *next;
};


// ...