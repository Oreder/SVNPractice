#include "hello.h"
#include "buy.h"

int main(void)
{
	hello();

	goodbuy();

	return  0;
}