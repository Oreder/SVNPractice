#include <stdio.h>
#include "hello.h"

void hello(void)
{
    printf("Hello, make!\n");
}