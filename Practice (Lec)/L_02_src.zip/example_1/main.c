// main.c

int main(void)
{
    hello();

    return 0;
}
