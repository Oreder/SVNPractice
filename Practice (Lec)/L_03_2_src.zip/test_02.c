/*
����� 5
*/

void f()
{
}

void g()
{
    return f();
}

int main(void)
{
    g();

    return 0;
}