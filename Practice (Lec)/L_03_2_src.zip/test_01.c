/*
����� 4
*/
#include <stdio.h>

f(void)
{
    return 10;
}

int main(void)
{
    printf("%d\n", f());

    return 0;
}