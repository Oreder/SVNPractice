#include <stdbool.h>
#include <stdio.h>

int main(void)
{
    bool flag = false;

    if (!flag)
        printf("flag is flase (%d)\n", flag);
        // flag is false (0)

    flag = true;

    if (flag)
        printf("flag is true (%d)\n", flag); 
        // flag is true (1)

    flag = 5;

    printf("flag is true (%d ops!)\n", flag);
    // flag is true (1 ops!)

    return 0;
}