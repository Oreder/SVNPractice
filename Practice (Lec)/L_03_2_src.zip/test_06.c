/*
����� 12
*/

#include <stdio.h>

int power(int base, int n)
{
    int result = 1;

    while (n-- > 0)
        result *= base;

    return result;
}

int main(void)
{
    int a, n = 5;

    printf("n = %d\n", n);             // n = 5

    a = power(2, n);

    printf("%d^%d = %d\n", 2, n, a);   // 2^5 = 32

    return 0;
}