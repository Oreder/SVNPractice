#include <stdio.h>

int main(void)
{
    char ch;
    int i;

    printf("%d\n", sizeof(ch));
    printf("%d\n", sizeof i);
    printf("%d\n", sizeof(double));


    return 0;
}