/*
����� 10
*/

#include <stdio.h>

int max(int a, int b)
{
    if (a < b)
        return b;

    return a;
}

int main(void)
{
    int n_chars;

    max(3, 5);

    n_chars = printf("Hello, world\n");

    printf("Hello, world\n");

    (void) printf("Hellow, world\n");

    return 0;
}
