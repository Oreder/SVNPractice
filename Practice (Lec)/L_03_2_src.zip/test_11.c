/*
����� 20
*/

#include <stdio.h>

int fibon(int n)
{
    if (n==0 || n==1)
        return n;

    return fibon(n-1) + fibon(n-2);
}

int main(void)
{
    int a = 6;

    printf("F%d = %d\n", a, fibon(a));

    return 0;
}