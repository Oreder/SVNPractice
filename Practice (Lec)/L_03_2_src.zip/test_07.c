/*
����� 13
*/

#include <stdio.h>

void swap(int a, int b)
{
    int temp = a;

    a = b;
    b = temp;
}

int main(void)
{
    int a = 3, b = 5;

    printf("a = %d, b = %d\n", a, b);  // a = 3, b = 5

    swap(a, b);

    printf("a = %d, b = %d\n", a, b);  // a = 3, b = 5

    return 0;
}