/*
������ 6, 9
*/

#include <stdio.h>

int max(int a, int b)
{
    if (a < b)
        return b;

    return a;
}

void print_pos(int a)
{
    if (a < 0)
        return;

    printf("%d\n", a);
}

void beep(void)
{
    printf("\a");

    return;  // �����, �� �����?
}

int main(void)
{
    int a = -5, b = -3, c;

    c = max(3, 5);

    if (max(a,b) < 0)
        printf("max is negative\n");

    beep();

    beep;

    return 0;
}
