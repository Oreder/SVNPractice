#include <stdio.h>

int main(void)
{
    _Bool flag = 0;

    if (!flag)
        printf("flag is flase (%d)\n", flag);
        // flag is false (0)

    flag = 1;

    if (flag)
        printf("flag is true (%d)\n", flag); 
        // flag is true (1)

    flag = 5;

    printf("flag is true (%d ops!)\n", flag);
    // flag is true (1 ops!)

    return 0;
}