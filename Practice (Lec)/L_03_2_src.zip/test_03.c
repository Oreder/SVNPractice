/*
����� 8
*/

#include <stdio.h>

void f()
{
    printf("f\n");
}

void g(void)
{
    printf("g\n");
}

int main(void)
{
    f();            // compilation error?

    g();            // compilation error?

    f(1, 2, 3);     // compilation error?

    g(1, 2, 3);     // compilation error?

    return 0;
}